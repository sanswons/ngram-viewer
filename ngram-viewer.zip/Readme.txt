1. The applicaion has been built using RStudio and ShinyApps.
2. Open https://sanswons.shinyapps.io/ngram-viewer/ to use the app.